let currentMusic = 0;

const music = document.querySelector('#audio');
const bar = document.querySelector('.seek-bar');
const songName = document.querySelector('.music-name');
const artist = document.querySelector('.artist');
const pause = document.querySelector('.play-btn');
const next = document.querySelector('.nxt-btn');
const back = document.querySelector('.pre-btn');
const disk = document.querySelector('.disk');
const time = document.querySelector('.time');
const duration = document.querySelector('.duration');

pause.addEventListener('click', ()=>{
  if (pause.className.includes('pause')){
    music.play()
  } else{
    music.pause()
  }
  pause.classList.toggle('pause');
  disk.classList.toggle('play');
})

const setMusic = (i) =>{
  bar.value=0;
  let song = songs[i];
  currentMusic =i;
  music.src= song.path;
  songName.innerHTML = song.name;
  artist.innerHTML= song.artist;
  disk.style.backgroundImage= `url('${song.cover}')`;
  time.innerHTML= '00:00';
  setTimeout(()=>{
    bar.max=music.duration;
    duration.innerHTML=formatTime(music.duration);
  },500);
}
setMusic(0);

const formatTime = (time) =>{
let min = Math.floor(time / 60);
if (min < 10){
  min=`0${min}`;
  }
  let sec = Math.floor(time % 60);
  if (sec < 10){
    sec=`0${sec}`;
  }
  return `${min} : ${sec}`;
}

setInterval(()=>{
  bar.value=music.currentTime;
  time.innerHTML=formatTime(music.currentTime)
},500)