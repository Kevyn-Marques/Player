let songs = [
    {
        name: 'Break',
        path: 'songs/Break - Good Kid.mp3',
        artist: 'Good Kid',
        cover: 'img/GoodKid1.jpeg'
    },
    {
        name: 'Madaleine',
        path: 'songs/Madeleine - Good Kid.mp3',
        artist: 'Good Kid',
        cover: 'img/GoodKid1.jpeg'
    },
    {
        name: 'From The Start',
        path: 'songs/From the Start - Good Kid.mp3',
        artist: 'Good Kid',
        cover: 'img/GoodKid2.jpeg'
    },
]